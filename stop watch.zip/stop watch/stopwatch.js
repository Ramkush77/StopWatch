let timer;
let isRunning = false;
let seconds = 0;
let minutes = 0;
let hours = 0;

const timeDisplay = document.getElementById("timeDisplay");
const startStopButton = document.getElementById("startStop");
const resetButton = document.getElementById("reset");

function startStop() {
  if (isRunning) {
    clearInterval(timer);
    startStopButton.textContent = "Start";
  } else {
    timer = setInterval(updateTime, 1000);
    startStopButton.textContent = "Stop";
  }
  isRunning = !isRunning;
}

function updateTime() {
  seconds++;
  if (seconds >= 60) {
    seconds = 0;
    minutes++;
  }
  if (minutes >= 60) {
    minutes = 0;
    hours++;
  }

  timeDisplay.textContent = formatTime(hours, minutes, seconds);
}

function formatTime(hours, minutes, seconds) {
  return (
    (hours < 10 ? "0" : "") +
    hours +
    ":" +
    (minutes < 10 ? "0" : "") +
    minutes +
    ":" +
    (seconds < 10 ? "0" : "") +
    seconds
  );
}

function reset() {
  clearInterval(timer);
  isRunning = false;
  hours = 0;
  minutes = 0;
  seconds = 0;
  timeDisplay.textContent = formatTime(hours, minutes, seconds);
  startStopButton.textContent = "Start";
}